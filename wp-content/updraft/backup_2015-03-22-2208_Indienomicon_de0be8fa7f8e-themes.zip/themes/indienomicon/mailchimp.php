<section class="section-callout">
  <div class="row">
    <div class="small-12 columns">
      <h2>Stay In-The-Loop</h2>
      <p>Sign up to receive notifications on our events and special announcements.</p>
      <!-- Begin MailChimp Signup Form -->
      <div id="mc_embed_signup">
        <form action="http://indienomicon.us6.list-manage.com/subscribe/post?u=09da9dc3ef&amp;id=0a20ed7988" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>

          <input type="email" value="" placeholder="Email Address" name="EMAIL" class="required email" id="mce-EMAIL">
          <input type="text" value="" name="FNAME" placeholder="First Name" class="required" id="mce-FNAME">
          <input class="button" type="submit" value="SUBSCRIBE" name="subscribe" id="mc-embedded-subscribe">

          <div id="mce-responses" class="clear">
            <div class="response" id="mce-error-response" style="display:none"></div>
            <div class="response" id="mce-success-response" style="display:none"></div>
          </div>
          <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
          <div style="position: absolute; left: -5000px;"><input type="text" name="b_09da9dc3ef_0a20ed7988" value=""></div>
        </form>
      </div>
    </div>
  </div>
</section>
