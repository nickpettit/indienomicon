<section class="row">
  <div class="small-12 columns">
    <h2>Indienomicon Sponsors</h2>
    <ul class="small-block-grid-1 medium-block-grid-2 large-block-grid-4">
      <li><a href="http://www.theindiebox.com/"><img src="<?php bloginfo('template_directory'); ?>/images/sponsors/indiebox.png" alt="The Indie Box"></a></li>
      <li><a href="http://www.terncraftgames.com/"><img src="<?php bloginfo('template_directory'); ?>/images/sponsors/terncraft.png" alt="Terncraft Games"></a></li>
      <li><a href="http://phykenmedia.com/"><img src="<?php bloginfo('template_directory'); ?>/images/sponsors/phyken.png" alt="Phyken Media"></a></li>
      <li><a href="http://kaleidoscopeit.com/"><img src="<?php bloginfo('template_directory'); ?>/images/sponsors/kaleidoscope.png" alt="Kaleidoscope Media"></a></li>
    <ul>
  </div>
</section>
