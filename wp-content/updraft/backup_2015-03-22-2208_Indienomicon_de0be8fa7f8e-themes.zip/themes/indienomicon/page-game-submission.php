<?php
/**
 * Template Name: Game Submission Form
 */

acf_form_head();

get_header();

the_post();

?>

<div class="row">
  <h2 class="small-12 columns"><?php echo get_the_title(); ?></h2>
</div>

<section class="row">

  <div class="small-12 columns">
    <div class="content-block-padded">
      <?php

  			$args = array(
          'id' => 'game-submission',
  				'post_id' => 'new',
  				'field_groups' => array( 1, 2, 3 )
  			);

  			acf_form( $args );

			?>
    </div>
  </div>
</section>

<?php get_footer(); ?>
